package com.example.Magazine;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Controller
public class Start {
    private List<Obiekt> listaLaptopow;
    private int zmienna;
    public Start() {
        Obiekt d = new Obiekt("D", "777");
        Obiekt l = new Obiekt("L", "T4");
        Obiekt h = new Obiekt("H", "G3");
        listaLaptopow = new ArrayList<>();
        listaLaptopow.add(d);
        listaLaptopow.add(l);
        listaLaptopow.add(h);
    }
    @GetMapping("/wpisz")
    public String dodawanie(Model model) {
        model.addAttribute("variables", new Variables());
        return "Dodawanie";
    }
    @GetMapping("")
    public String get(Model model) {
        model.addAttribute("lista", listaLaptopow);
        model.addAttribute("nowyLaptop", new Obiekt());
        return "Glowna";
    }

    @PostMapping("")
    public String dodawanieLaptopow(@ModelAttribute Obiekt laptop) {
        listaLaptopow.add(laptop);
        return "redirect:/";
    }
    @PostMapping("/wpisz")
    public String dodawanieObiekt(@ModelAttribute Variables variables) {
        int x;
        x = variables.getA();
        zmienna = variables.getB();
        System.out.println(x);
        System.out.println(zmienna);
        return "redirect:/wpisz";
    }
}
