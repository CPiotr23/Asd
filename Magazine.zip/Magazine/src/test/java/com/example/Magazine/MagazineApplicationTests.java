package com.example.Magazine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MagazineApplicationTests {

	@Test
	void contextLoads() {
	}

}
